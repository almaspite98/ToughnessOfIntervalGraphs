package intervalGraph;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class Point {
    public float x;
    public int c; //x1 vagy x2 ??? +1 -1
}
